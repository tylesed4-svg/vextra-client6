# Vextra Client
Target: Minecraft 1.21.11, Java 21, Fabric Loader 0.17.3+, Fabric API 0.141.5+1.21.11.
Build: GitHub Actions (see workflow) or `gradle build` -> build/libs/vextra-client-0.1.0.jar
Install: put the JAR + Fabric API in `mods`. Open the menu with RIGHT SHIFT; H hides/shows all HUD (rebind both in Controls).

## Features
- HUD modules (each fully optional: toggle, drag-and-drop, scale, colors RGB, opacity, padding,
  border, rounded corners, text shadow): FPS, CPS, Ping, Coordinates, Sprint status, Combo/Hits,
  Health (hearts/percent/absorption), Armor HUD (durability %, low warning, horizontal/vertical),
  Potion HUD (sort, compact), Target info, Totem warning, Keystrokes (WASD, Space, LMB, RMB).
- Custom crosshair: size, thickness, gap, opacity, colors, outline, dot, dynamic expansion, presets, live preview.
- Utility: No pumpkin blur, Auto Sprint, Toggle Sneak (key), Quick Totem Swap (key V, off by default).
- Settings menu: search, live HUD, reset, Minimal/Full presets, 3 save slots, export/import via clipboard.
- Config: config/vextra/config.json (atomic saves).

## Not implemented yet (honest list)
Fog controls, low fire/shield, item scaling, boat map, gamemode switcher, riptide fix (need mixins, coming in small batches), motion blur, shulker tooltip preview, hit color, damage indicators, freelook/perspective controls,
custom fonts. These need mixins/shaders and will be added only after this build is confirmed working.

## Visual tweaks (General / Utility)
No pumpkin blur, No frost, Clear water overlay, Low fire %, Low shield %, first-person
size for totems/potions/food. Implemented with fail-safe mixins (targets checked for 1.21.11): if a target
does not apply, the game still runs and only that tweak is skipped.
