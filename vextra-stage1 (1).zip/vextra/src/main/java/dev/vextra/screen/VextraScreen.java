package dev.vextra.screen;

import dev.vextra.config.VextraConfig;
import dev.vextra.crosshair.CrosshairRenderer;
import dev.vextra.hud.HudManager;
import dev.vextra.module.HudModule;
import dev.vextra.module.Modules;
import dev.vextra.module.Opt;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/**
 * Settings menu. Uses immediate-mode widgets driven by polled mouse state, so it does not depend
 * on version-specific mouse event classes. Drag any HUD element with the mouse to move it.
 */
public final class VextraScreen extends Screen {
    private static final int LW = 112, RW = 156, RM = 30, RH = 13, ACCENT = 0xFF8B5CFF;

    private record Entry(String id, String name, BooleanSupplier get, Consumer<Boolean> set) {}

    private final Screen parent;
    private final List<Entry> entries = new ArrayList<>();
    private EditBox search;
    private String selected = "fps";
    private boolean wasDown, down, pressed;
    private String activeSlider;
    private HudModule dragging;
    private int dx, dy, mx, my;
    private boolean clickPending;
    private int clickX, clickY;
    private boolean collapsed;
    private String toast = "";
    private long toastUntil;

    public VextraScreen(Screen parent) {
        super(Component.literal("Vextra"));
        this.parent = parent;
        for (HudModule m : Modules.ALL)
            entries.add(new Entry(m.id, m.displayName, () -> m.settings().enabled, v -> m.settings().enabled = v));
        entries.add(new Entry("crosshair", "Crosshair",
            () -> VextraConfig.get().crosshair.enabled, v -> VextraConfig.get().crosshair.enabled = v));
        entries.add(new Entry("general", "General / Utility", null, null));
    }

    @Override
    protected void init() {
        HudManager.editing = true;
        search = new EditBox(this.minecraft.font, 6, 20, LW - 12, 12, Component.literal("Search"));
        search.setHint(Component.literal("Search..."));
        addRenderableWidget(search);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() == 0) {
            clickPending = true; down = true;
            clickX = (int) event.x(); clickY = (int) event.y();
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (event.button() == 0) down = false;
        return super.mouseReleased(event);
    }

    @Override public void removed() { HudManager.editing = false; VextraConfig.save(); }
    @Override public void onClose() { this.minecraft.setScreen(parent); }

    @Override
    public void renderBackground(GuiGraphics g, int a, int b, float c) {
        if (collapsed) { g.fill(0, 0, width, height, 0x18000000); return; }
        g.fill(0, 0, width, height, 0x40000000);
        g.fill(0, 0, LW, height, 0xDD0E0E16);
        g.fill(width - RW - RM, 0, width, height, 0xDD0E0E16);
        g.fill(LW, 0, LW + 1, height, ACCENT);
        g.fill(width - RW - RM - 1, 0, width - RW - RM, height, ACCENT);
    }

    // ---------------------------------------------------------------- frame
    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float pt) {
        mx = mouseX; my = mouseY;
        pressed = clickPending;
        clickPending = false;
        if (pressed) { mx = clickX; my = clickY; }

        super.render(g, mouseX, mouseY, pt);

        int btnTop = bottomTop();
        boolean overToggle = mx >= width / 2 - 32 && mx <= width / 2 + 32 && my < 17;
        boolean overPanel = overToggle
            || (!collapsed && (mx < LW || mx > width - RW - RM - 1 || my >= btnTop));
        handleDrag(overPanel);
        outlineSelected(g);
        if (!collapsed) {
            drawList(g);
            drawOptions(g);
            drawButtons(g, btnTop);
        }
        if (button(g, width / 2 - 30, 4, 60, 11, collapsed ? "Show menu" : "Hide menu")) {
            collapsed = !collapsed;
            search.visible = !collapsed;
        }
        if (System.currentTimeMillis() < toastUntil)
            g.drawCenteredString(minecraft.font, toast, width / 2, 20, 0xFFFFFFFF);

        if (!down) activeSlider = null;
    }

    private void handleDrag(boolean overPanel) {
        if (pressed && !overPanel) {
            dragging = null;
            for (int i = Modules.ALL.size() - 1; i >= 0; i--) {
                HudModule m = Modules.ALL.get(i);
                if (m.bw > 0 && mx >= m.bx && mx < m.bx + m.bw && my >= m.by && my < m.by + m.bh) {
                    dragging = m; selected = m.id; dx = mx - m.bx; dy = my - m.by;
                    break;
                }
            }
        }
        if (dragging != null) {
            if (down || pressed) {
                var s = dragging.settings();
                s.x = Math.clamp(mx - dx, 0, Math.max(0, width - dragging.bw));
                s.y = Math.clamp(my - dy, 0, Math.max(0, height - dragging.bh));
            } else {
                dragging = null;
                VextraConfig.save();
            }
        }
    }

    private void outlineSelected(GuiGraphics g) {
        for (HudModule m : Modules.ALL) {
            if (m.bw <= 0) continue;
            boolean sel = m.id.equals(selected);
            int c = sel ? ACCENT : 0x44FFFFFF;
            g.fill(m.bx - 1, m.by - 1, m.bx + m.bw + 1, m.by, c);
            g.fill(m.bx - 1, m.by + m.bh, m.bx + m.bw + 1, m.by + m.bh + 1, c);
            g.fill(m.bx - 1, m.by, m.bx, m.by + m.bh, c);
            g.fill(m.bx + m.bw, m.by, m.bx + m.bw + 1, m.by + m.bh, c);
        }
    }

    // ---------------------------------------------------------------- left list
    private void drawList(GuiGraphics g) {
        g.drawString(minecraft.font, "§l§dVEXTRA §7CLIENT", 6, 6, 0xFFFFFFFF, false);
        String q = search.getValue().toLowerCase();
        int y = 38;
        for (Entry e : entries) {
            if (!q.isEmpty() && !e.name().toLowerCase().contains(q)) continue;
            boolean sel = e.id().equals(selected);
            boolean hover = mx < LW && my >= y && my < y + 12;
            if (sel) g.fill(0, y, LW, y + 12, 0x558B5CFF);
            else if (hover) g.fill(0, y, LW, y + 12, 0x22FFFFFF);
            g.drawString(minecraft.font, e.name(), 6, y + 2, 0xFFFFFFFF, false);
            boolean clickedPill = false;
            if (e.get() != null) {
                boolean on = e.get().getAsBoolean();
                int px = LW - 26;
                g.fill(px, y + 1, px + 22, y + 11, on ? 0xFF2ECC71 : 0xFF555566);
                g.drawString(minecraft.font, on ? "ON" : "OFF", px + (on ? 6 : 4), y + 2, 0xFFFFFFFF, false);
                if (pressed && mx >= px && mx < px + 22 && my >= y && my < y + 12) {
                    e.set().accept(!on); clickedPill = true; click(on ? 0.8f : 1.3f);
                }
            }
            if (pressed && hover && !clickedPill && mx < LW - 26) { selected = e.id(); click(1.1f); }
            y += 13;
        }
    }

    // ---------------------------------------------------------------- right panel
    private void drawOptions(GuiGraphics g) {
        int x = width - RW - RM + 6, w = RW - 12, y = 6;
        String title = "General / Utility";
        for (Entry e : entries) if (e.id().equals(selected)) title = e.name();
        g.drawString(minecraft.font, "§l" + title, x, y, 0xFFFFFFFF, false);
        y = 20;
        VextraConfig cfg = VextraConfig.get();

        if (selected.equals("general")) {
            var gen = cfg.general;
            gen.autoSprint = toggle(g, x, y, w, "Auto Sprint", gen.autoSprint); y += RH;
            gen.fastTotem = toggle(g, x, y, w, "Fast Totem", gen.fastTotem); y += RH;
            gen.noPumpkinBlur = toggle(g, x, y, w, "No pumpkin blur", gen.noPumpkinBlur); y += RH;
            gen.noFrost = toggle(g, x, y, w, "No frost overlay", gen.noFrost); y += RH;
            gen.clearWater = toggle(g, x, y, w, "Clear water overlay", gen.clearWater); y += RH;
            gen.lowFire = Math.round(slider(g, x, y, w, "lf", "Low fire %", gen.lowFire, 0, 100, true, ACCENT)); y += RH;
            gen.lowShield = Math.round(slider(g, x, y, w, "ls", "Low shield %", gen.lowShield, 0, 100, true, ACCENT)); y += RH;
            gen.scaleTotem = slider(g, x, y, w, "st", "Totem size", gen.scaleTotem, 0.3f, 2f, false, ACCENT); y += RH;
            gen.scalePotion = slider(g, x, y, w, "sp", "Potion size", gen.scalePotion, 0.3f, 2f, false, ACCENT); y += RH;
            gen.scaleFood = slider(g, x, y, w, "sf", "Food size", gen.scaleFood, 0.3f, 2f, false, ACCENT); y += RH + 3;
            String[] info = {"§7Menu: Right Shift  HUD hide: H", "§7Fast totem: Shift+RClick in inventory", "§7or V key in-game"};
            for (String s : info) { g.drawString(minecraft.font, s, x, y, 0xFFFFFFFF, false); y += 10; }
        } else if (selected.equals("crosshair")) {
            var c = cfg.crosshair;
            g.fill(x, y, x + w, y + 44, 0xFF1A1A24);
            float ex = c.dynamic ? (float) (Math.sin(System.currentTimeMillis() / 400.0) + 1) / 2f * c.dynamicAmount : 0;
            CrosshairRenderer.draw(g, x + w / 2, y + 22, c, ex);
            y += 48;
            c.enabled = toggle(g, x, y, w, "Custom crosshair", c.enabled); y += RH;
            c.dynamic = toggle(g, x, y, w, "Dynamic", c.dynamic); y += RH;
            c.outline = toggle(g, x, y, w, "Outline", c.outline); y += RH;
            c.dot = toggle(g, x, y, w, "Center dot", c.dot); y += RH;
            c.size = Math.round(slider(g, x, y, w, "xs", "Size", c.size, 0, 20, true, ACCENT)); y += RH;
            c.thickness = Math.round(slider(g, x, y, w, "xt", "Thickness", c.thickness, 1, 5, true, ACCENT)); y += RH;
            c.gap = Math.round(slider(g, x, y, w, "xg", "Gap", c.gap, 0, 12, true, ACCENT)); y += RH;
            c.opacity = slider(g, x, y, w, "xo", "Opacity", c.opacity, 0.1f, 1f, false, ACCENT); y += RH;
            c.dynamicAmount = Math.round(slider(g, x, y, w, "xd", "Dyn. amount", c.dynamicAmount, 0, 10, true, ACCENT)); y += RH;
            c.color = colorRow(g, x, y, w, "xc", "Color", c.color); y += RH;
            c.outlineColor = colorRow(g, x, y, w, "xk", "Outline", c.outlineColor); y += RH + 2;
            int bw = (w - 4) / 3;
            String[] names = {"Classic", "Dot", "Wide"};
            for (int i = 0; i < 3; i++)
                if (button(g, x + i * (bw + 2), y, bw, 11, names[i])) c.preset(names[i]);
        } else {
            HudModule m = null;
            for (HudModule h : Modules.ALL) if (h.id.equals(selected)) m = h;
            if (m == null) return;
            var s = m.settings();
            s.enabled = toggle(g, x, y, w, "Enabled", s.enabled); y += RH;
            s.scale = slider(g, x, y, w, "sc", "Scale", s.scale, 0.5f, 3f, false, ACCENT); y += RH;
            s.bgOpacity = slider(g, x, y, w, "bo", "BG opacity", s.bgOpacity, 0f, 1f, false, ACCENT); y += RH;
            s.padding = Math.round(slider(g, x, y, w, "pd", "Padding", s.padding, 0, 10, true, ACCENT)); y += RH;
            s.borderWidth = Math.round(slider(g, x, y, w, "bw", "Border", s.borderWidth, 0, 3, true, ACCENT)); y += RH;
            s.rounded = toggle(g, x, y, w, "Rounded corners", s.rounded); y += RH;
            s.shadow = toggle(g, x, y, w, "Text shadow", s.shadow); y += RH;
            s.textColor = colorRow(g, x, y, w, "tc", "Text", s.textColor); y += RH;
            s.bgColor = colorRow(g, x, y, w, "bc", "BG", s.bgColor); y += RH;
            s.borderColor = colorRow(g, x, y, w, "oc", "Border", s.borderColor); y += RH + 2;
            for (Opt o : m.options()) {
                if (o.toggle) o.setB.accept(toggle(g, x, y, w, o.label, o.getB.getAsBoolean()));
                else o.setF.accept(slider(g, x, y, w, "o" + o.label, o.label, o.getF.get(), o.min, o.max, o.integer, ACCENT));
                y += RH;
            }
            g.drawString(minecraft.font, "§7Tip: drag the element on screen", x, y + 4, 0xFFFFFFFF, false);
        }
    }

    // ---------------------------------------------------------------- bottom buttons
    private static final String[] BTN = {"Reset", "Center", "Reset ALL", "Minimal", "Full", "Export", "Import",
        "Save 1", "Save 2", "Save 3", "Load 1", "Load 2", "Load 3"};

    private int perRow() { return Math.max(1, (width - LW - RW - RM - 8) / 42); }
    private int bottomTop() { int rows = (BTN.length + perRow() - 1) / perRow(); return height - 4 - rows * 13; }

    private void drawButtons(GuiGraphics g, int top) {
        int per = perRow();
        for (int i = 0; i < BTN.length; i++) {
            int x = LW + 5 + (i % per) * 42, y = top + (i / per) * 13;
            if (button(g, x, y, 40, 11, BTN[i])) action(BTN[i]);
        }
    }

    private void action(String b) {
        switch (b) {
            case "Reset" -> {
                var c = VextraConfig.get();
                if (selected.equals("crosshair")) c.crosshair = new VextraConfig.CrosshairSettings();
                else if (selected.equals("general")) c.general = new VextraConfig.General();
                else c.modules.remove(selected);
                say("Reset");
            }
            case "Center" -> {
                for (HudModule m : Modules.ALL) if (m.id.equals(selected)) {
                    var st = m.settings();
                    st.x = Math.max(0, width / 2 - m.bw / 2);
                    st.y = Math.max(0, height / 2 - m.bh / 2);
                    say("Moved to center");
                }
            }
            case "Reset ALL" -> { VextraConfig.resetAll(); say("Everything reset"); }
            case "Minimal", "Full" -> { VextraConfig.applyPreset(b); say("Preset: " + b); }
            case "Export" -> { minecraft.keyboardHandler.setClipboard(VextraConfig.exportString()); say("Config copied to clipboard"); }
            case "Import" -> say(VextraConfig.importString(minecraft.keyboardHandler.getClipboard()) ? "Imported from clipboard" : "Clipboard has no valid config");
            default -> {
                int n = b.charAt(b.length() - 1) - '0';
                if (b.startsWith("Save")) { VextraConfig.saveProfile(n); say("Saved to slot " + n); }
                else say(VextraConfig.loadProfile(n) ? "Loaded slot " + n : "Slot " + n + " is empty");
            }
        }
    }

    private void click(float pitch) {
        minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, pitch));
    }

    private void say(String s) { toast = s; toastUntil = System.currentTimeMillis() + 2000; }

    // ---------------------------------------------------------------- widgets
    private boolean button(GuiGraphics g, int x, int y, int w, int h, String label) {
        boolean hover = mx >= x && mx < x + w && my >= y && my < y + h;
        g.fill(x, y, x + w, y + h, hover ? 0xFF3A3A55 : 0xFF24243A);
        g.drawString(minecraft.font, label, x + (w - minecraft.font.width(label)) / 2, y + 2, 0xFFFFFFFF, false);
        if (pressed && hover) { click(1.0f); return true; }
        return false;
    }

    private boolean toggle(GuiGraphics g, int x, int y, int w, String label, boolean v) {
        boolean hover = mx >= x && mx < x + w && my >= y && my < y + RH - 2;
        g.fill(x, y, x + w, y + RH - 2, hover ? 0xFF2A2A40 : 0xFF1C1C2C);
        g.drawString(minecraft.font, label, x + 3, y + 2, 0xFFFFFFFF, false);
        String t = v ? "ON" : "OFF";
        g.drawString(minecraft.font, t, x + w - minecraft.font.width(t) - 3, y + 2, v ? 0xFF2ECC71 : 0xFF888899, false);
        if (pressed && hover) { click(v ? 0.8f : 1.3f); return !v; }
        return v;
    }

    private float slider(GuiGraphics g, int x, int y, int w, String id, String label,
                         float v, float min, float max, boolean integer, int fill) {
        boolean hover = mx >= x && mx < x + w && my >= y && my < y + RH - 2;
        if (pressed && hover) { activeSlider = id; click(1.6f); }
        if (id.equals(activeSlider) && (down || pressed)) {
            float t = Math.clamp((mx - x) / (float) w, 0f, 1f);
            v = min + t * (max - min);
            if (integer) v = Math.round(v);
        }
        float t = max == min ? 0 : Math.clamp((v - min) / (max - min), 0f, 1f);
        g.fill(x, y, x + w, y + RH - 2, 0xFF1C1C2C);
        g.fill(x, y, x + Math.round(w * t), y + RH - 2, (fill & 0x00FFFFFF) | 0x99000000);
        g.drawString(minecraft.font, label, x + 3, y + 2, 0xFFFFFFFF, false);
        String val = integer ? String.valueOf(Math.round(v)) : String.format("%.2f", v);
        g.drawString(minecraft.font, val, x + w - minecraft.font.width(val) - 3, y + 2, 0xFFFFFFFF, false);
        return v;
    }

    private int colorRow(GuiGraphics g, int x, int y, int w, String id, String label, int rgb) {
        g.drawString(minecraft.font, label, x + 2, y + 2, 0xFFFFFFFF, false);
        int sx = x + 40, sw = (w - 40 - 12) / 3;
        int r = (rgb >> 16) & 255, gr = (rgb >> 8) & 255, b = rgb & 255;
        r = Math.round(slider(g, sx, y, sw, id + "r", "", r, 0, 255, true, 0xFFFF4444));
        gr = Math.round(slider(g, sx + sw + 1, y, sw, id + "g", "", gr, 0, 255, true, 0xFF44FF44));
        b = Math.round(slider(g, sx + 2 * (sw + 1), y, sw, id + "b", "", b, 0, 255, true, 0xFF4488FF));
        int out = (r << 16) | (gr << 8) | b;
        g.fill(x + w - 10, y + 1, x + w - 1, y + RH - 3, 0xFF000000 | out);
        return out;
    }
}
