package dev.vextra;

import dev.vextra.config.VextraConfig;
import dev.vextra.feature.Features;
import dev.vextra.feature.Keys;
import dev.vextra.hud.HudManager;
import net.fabricmc.api.ClientModInitializer;

public final class VextraClient implements ClientModInitializer {
    public static final String ID = "vextra";

    @Override
    public void onInitializeClient() {
        VextraConfig.load();
        Keys.init();
        HudManager.init();
        Features.init();
    }
}
