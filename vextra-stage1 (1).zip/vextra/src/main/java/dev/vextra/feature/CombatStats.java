package dev.vextra.feature;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

public final class CombatStats {
    public static int hits, combo, taken;
    public static LivingEntity lastTarget;
    public static long lastHit;
    private static int prevHurt;

    public static void onAttack(Entity e) {
        hits++; combo++; lastHit = System.currentTimeMillis();
        if (e instanceof LivingEntity le) lastTarget = le;
    }

    public static boolean recentAttack() { return System.currentTimeMillis() - lastHit < 250; }

    public static void tick(Minecraft mc) {
        if (mc.player == null) return;
        int ht = mc.player.hurtTime;
        if (ht > 0 && prevHurt == 0) { taken++; combo = 0; }
        prevHurt = ht;
        long now = System.currentTimeMillis();
        if (combo > 0 && now - lastHit > 3000) combo = 0;
        if (lastTarget != null && (now - lastHit > 3000 || !lastTarget.isAlive())) lastTarget = null;
    }
    private CombatStats() {}
}
