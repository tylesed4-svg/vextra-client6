package dev.vextra.feature;

import com.mojang.blaze3d.platform.InputConstants;
import dev.vextra.VextraClient;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public final class Keys {
    public static final KeyMapping.Category CAT =
        KeyMapping.Category.register(Identifier.fromNamespaceAndPath(VextraClient.ID, "main"));
    public static final KeyMapping MENU = KeyBindingHelper.registerKeyBinding(
        new KeyMapping("key.vextra.menu", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, CAT));
    public static final KeyMapping TOTEM = KeyBindingHelper.registerKeyBinding(
        new KeyMapping("key.vextra.totem", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_V, CAT));
    public static final KeyMapping SNEAK = KeyBindingHelper.registerKeyBinding(
        new KeyMapping("key.vextra.sneak", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, CAT));

    public static final KeyMapping HIDE = KeyBindingHelper.registerKeyBinding(
        new KeyMapping("key.vextra.hide", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_H, CAT));

    public static void init() {} // forces class loading
    private Keys() {}
}
