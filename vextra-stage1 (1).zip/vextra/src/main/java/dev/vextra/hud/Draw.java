package dev.vextra.hud;

import net.minecraft.client.gui.GuiGraphics;

public final class Draw {
    public static void box(GuiGraphics g, int x, int y, int w, int h, int bgArgb, int borderRgb, int bw, boolean round) {
        if (bw > 0) {
            int c = 0xFF000000 | borderRgb;
            g.fill(x - bw, y - bw, x + w + bw, y, c);
            g.fill(x - bw, y + h, x + w + bw, y + h + bw, c);
            g.fill(x - bw, y, x, y + h, c);
            g.fill(x + w, y, x + w + bw, y + h, c);
        }
        if (!round || w < 6 || h < 6) { g.fill(x, y, x + w, y + h, bgArgb); return; }
        g.fill(x + 2, y, x + w - 2, y + 1, bgArgb);
        g.fill(x + 1, y + 1, x + w - 1, y + 2, bgArgb);
        g.fill(x, y + 2, x + w, y + h - 2, bgArgb);
        g.fill(x + 1, y + h - 2, x + w - 1, y + h - 1, bgArgb);
        g.fill(x + 2, y + h - 1, x + w - 2, y + h, bgArgb);
    }
    private Draw() {}
}
