package dev.vextra.hud;

import dev.vextra.VextraClient;
import dev.vextra.config.VextraConfig;
import dev.vextra.crosshair.CrosshairRenderer;
import dev.vextra.module.HudModule;
import dev.vextra.module.Modules;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.Identifier;

/** All version-sensitive HUD rendering lives here. */
public final class HudManager {
    /** True while the Vextra menu is open: hidden modules show placeholders so they can be dragged. */
    public static boolean editing;
    /** Master hide switch (key H): hides every Vextra HUD element instantly. */
    public static boolean hidden;

    public static void init() {
        HudElementRegistry.attachElementAfter(
            VanillaHudElements.MISC_OVERLAYS,
            Identifier.fromNamespaceAndPath(VextraClient.ID, "hud"),
            (graphics, tickCounter) -> render(graphics));

        HudElementRegistry.replaceElement(VanillaHudElements.CROSSHAIR, original -> (g, tick) -> {
            VextraConfig.CrosshairSettings c = VextraConfig.get().crosshair;
            if (!c.enabled) { original.render(g, tick); return; }
            Minecraft mc = Minecraft.getInstance();
            if (!mc.options.getCameraType().isFirstPerson()) return;
            CrosshairRenderer.draw(g, g.guiWidth() / 2, g.guiHeight() / 2, c, CrosshairRenderer.expansion(mc, c));
        });
    }

    private static void render(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui || mc.player == null || (hidden && !editing)) return;
        for (HudModule m : Modules.ALL) {
            m.frame(mc);
            VextraConfig.ModuleSettings s = m.settings();
            if (!s.enabled) { m.bw = m.bh = 0; continue; }

            int p = s.padding, w, h;
            String[] ls = null;
            if (m.custom()) {
                w = m.width(mc, s); h = m.height(mc, s);
            } else {
                ls = m.lines(mc);
                if (ls == null) { String t = m.text(mc); if (t != null) ls = new String[]{t}; }
                if (ls == null) {
                    if (editing) ls = new String[]{m.displayName};
                    else { m.bw = m.bh = 0; continue; }
                }
                w = 0;
                for (String l : ls) w = Math.max(w, mc.font.width(l));
                h = ls.length * (mc.font.lineHeight + 1) - 1;
            }
            int ow = w + 2 * p, oh = h + 2 * p;
            int sw = Math.round(ow * s.scale), sh = Math.round(oh * s.scale);
            s.x = Math.clamp(s.x, 0, Math.max(0, g.guiWidth() - sw));
            s.y = Math.clamp(s.y, 0, Math.max(0, g.guiHeight() - sh));
            m.bx = s.x; m.by = s.y; m.bw = sw; m.bh = sh;

            int a = Math.round(Math.clamp(s.bgOpacity, 0f, 1f) * 255f);
            int bg = (a << 24) | (s.bgColor & 0xFFFFFF);

            g.pose().pushMatrix();
            g.pose().translate(s.x, s.y);
            g.pose().scale(s.scale, s.scale);
            Draw.box(g, 0, 0, ow, oh, bg, s.borderColor, s.borderWidth, s.rounded);
            if (m.custom()) {
                g.pose().translate(p, p);
                m.draw(g, mc, s);
            } else {
                int lh = mc.font.lineHeight + 1, tc = 0xFF000000 | s.textColor;
                for (int i = 0; i < ls.length; i++)
                    g.drawString(mc.font, ls[i], p, p + i * lh, tc, s.shadow);
            }
            g.pose().popMatrix();
        }
    }
    private HudManager() {}
}
