package dev.vextra.mixin;

import dev.vextra.config.VextraConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Fast Totem: Shift + right-click on a totem in any inventory sends the normal
 * "swap with offhand" click (same as pressing the swap-hands key over the slot).
 */
@Mixin(AbstractContainerScreen.class)
public abstract class SlotClickMixin {
    @Inject(method = "slotClicked", at = @At("HEAD"), cancellable = true, require = 0)
    private void vextra$fastTotem(Slot slot, int slotId, int button, ClickType type, CallbackInfo ci) {
        if (slot == null || button != 1 || type != ClickType.QUICK_MOVE) return;
        if (!VextraConfig.get().general.fastTotem) return;
        if (!slot.hasItem() || !slot.getItem().is(Items.TOTEM_OF_UNDYING)) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.gameMode == null || mc.player == null) return;
        AbstractContainerScreen<?> self = (AbstractContainerScreen<?>) (Object) this;
        mc.gameMode.handleInventoryMouseClick(self.getMenu().containerId, slotId, 40, ClickType.SWAP, mc.player);
        ci.cancel();
    }
}
