package dev.vextra.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.vextra.config.VextraConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.ScreenEffectRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Target verified for 1.21.11: ScreenEffectRenderer.renderWater(Minecraft, PoseStack, MultiBufferSource). */
@Mixin(ScreenEffectRenderer.class)
public abstract class WaterMixin {
    @Inject(method = "renderWater", at = @At("HEAD"), cancellable = true, require = 0)
    private static void vextra$water(Minecraft mc, PoseStack ps, MultiBufferSource buf, CallbackInfo ci) {
        if (VextraConfig.get().general.clearWater) ci.cancel();
    }
}
