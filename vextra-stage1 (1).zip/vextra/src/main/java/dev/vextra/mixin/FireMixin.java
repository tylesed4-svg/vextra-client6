package dev.vextra.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.vextra.config.VextraConfig;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.ScreenEffectRenderer;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Target verified for 1.21.11: ScreenEffectRenderer.renderFire(PoseStack, MultiBufferSource, TextureAtlasSprite). */
@Mixin(ScreenEffectRenderer.class)
public abstract class FireMixin {
    @Unique private static boolean vextra$pushed;

    @Inject(method = "renderFire", at = @At("HEAD"), cancellable = true, require = 0)
    private static void vextra$fireHead(PoseStack ps, MultiBufferSource buf, TextureAtlasSprite sprite, CallbackInfo ci) {
        int p = VextraConfig.get().general.lowFire;
        vextra$pushed = false;
        if (p <= 0) return;
        if (p >= 100) { ci.cancel(); return; }
        ps.pushPose();
        ps.translate(0f, -p / 100f * 0.5f, 0f);
        vextra$pushed = true;
    }

    @Inject(method = "renderFire", at = @At("RETURN"), require = 0)
    private static void vextra$fireTail(PoseStack ps, MultiBufferSource buf, TextureAtlasSprite sprite, CallbackInfo ci) {
        if (vextra$pushed) { ps.popPose(); vextra$pushed = false; }
    }
}
