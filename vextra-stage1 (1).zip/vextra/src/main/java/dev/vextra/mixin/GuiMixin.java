package dev.vextra.mixin;

import dev.vextra.config.VextraConfig;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Target verified for 1.21.11: Gui.renderTextureOverlay(GuiGraphics, Identifier, float). */
@Mixin(Gui.class)
public abstract class GuiMixin {
    @Inject(method = "renderTextureOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private void vextra$overlay(GuiGraphics g, Identifier id, float alpha, CallbackInfo ci) {
        if (id == null) return;
        var gen = VextraConfig.get().general;
        String p = id.getPath();
        if (gen.noPumpkinBlur && p.contains("pumpkinblur")) ci.cancel();
        else if (gen.noFrost && p.contains("powder_snow")) ci.cancel();
    }
}
