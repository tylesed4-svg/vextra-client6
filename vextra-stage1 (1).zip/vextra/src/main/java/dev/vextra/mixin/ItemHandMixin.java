package dev.vextra.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.vextra.config.VextraConfig;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** First-person item scaling and low shield. Target (1.21.11): ItemInHandRenderer.renderArmWithItem. */
@Mixin(ItemInHandRenderer.class)
public abstract class ItemHandMixin {
    @Unique private boolean vextra$pushed;

    @Inject(method = "renderArmWithItem", at = @At("HEAD"), require = 0)
    private void vextra$head(AbstractClientPlayer player, float pt, float pitch, InteractionHand hand,
                             float swing, ItemStack stack, float equip, PoseStack ps,
                             @Coerce Object collector, int light, CallbackInfo ci) {
        vextra$pushed = false;
        var g = VextraConfig.get().general;
        float s = 1f, drop = 0f;
        if (stack.is(Items.TOTEM_OF_UNDYING)) s = g.scaleTotem;
        else if (stack.is(Items.POTION) || stack.is(Items.SPLASH_POTION) || stack.is(Items.LINGERING_POTION)) s = g.scalePotion;
        else if (stack.has(DataComponents.FOOD)) s = g.scaleFood;
        if (stack.is(Items.SHIELD)) drop = g.lowShield / 100f * 0.4f;
        if (s == 1f && drop == 0f) return;
        ps.pushPose();
        if (drop != 0f) ps.translate(0f, -drop, 0f);
        if (s != 1f) ps.scale(s, s, s);
        vextra$pushed = true;
    }

    @Inject(method = "renderArmWithItem", at = @At("RETURN"), require = 0)
    private void vextra$tail(AbstractClientPlayer player, float pt, float pitch, InteractionHand hand,
                             float swing, ItemStack stack, float equip, PoseStack ps,
                             @Coerce Object collector, int light, CallbackInfo ci) {
        if (vextra$pushed) { ps.popPose(); vextra$pushed = false; }
    }
}
