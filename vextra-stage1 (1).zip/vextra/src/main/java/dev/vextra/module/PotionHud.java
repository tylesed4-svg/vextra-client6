package dev.vextra.module;

import net.minecraft.client.Minecraft;
import net.minecraft.world.effect.MobEffectInstance;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class PotionHud extends HudModule {
    public PotionHud() { super("potions", "Potion HUD", 4, 230); }

    @Override
    public String[] lines(Minecraft mc) {
        if (mc.player == null || mc.player.getActiveEffects().isEmpty()) return null;
        List<MobEffectInstance> list = new ArrayList<>();
        for (MobEffectInstance e : mc.player.getActiveEffects()) if (e.isVisible()) list.add(e);
        if (list.isEmpty()) return null;
        if (settings().sortByDuration) list.sort(Comparator.comparingInt(MobEffectInstance::getDuration).reversed());
        else list.sort(Comparator.comparing(e -> e.getEffect().value().getDisplayName().getString()));
        String[] out = new String[list.size()];
        for (int i = 0; i < out.length; i++) {
            MobEffectInstance e = list.get(i);
            String name = e.getEffect().value().getDisplayName().getString();
            if (e.getAmplifier() > 0) name += " " + (e.getAmplifier() + 1);
            out[i] = settings().showNames ? name + "  " + time(e) : time(e);
        }
        return out;
    }

    private static String time(MobEffectInstance e) {
        if (e.isInfiniteDuration()) return "**:**";
        int s = e.getDuration() / 20;
        return (s / 60) + ":" + String.format("%02d", s % 60);
    }

    @Override public List<Opt> options() {
        return List.of(
            Opt.toggle("Sort by duration", () -> settings().sortByDuration, v -> settings().sortByDuration = v),
            Opt.toggle("Show names", () -> settings().showNames, v -> settings().showNames = v));
    }
}
